import { createContext } from 'react'

const TogglerContext = createContext()

export default TogglerContext
